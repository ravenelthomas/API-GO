package tlsconfig

import (
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"os"
	"path/filepath"
	"reflect"
	"testing"
)

const (
	rsaPrivateKeyFile             = "fixtures/key.pem"
	certificateFile               = "fixtures/cert.pem"
	multiCertificateFile          = "fixtures/multi.pem"
	rsaEncryptedPrivateKeyFile    = "fixtures/encrypted_key.pem"         // TODO add code to regenerate in fixtures/generate.go
	certificateOfEncryptedKeyFile = "fixtures/cert_of_encrypted_key.pem" // TODO add code to regenerate in fixtures/generate.go
)

// returns the name of a pre-generated, multiple-certificate CA file
// with both RSA and ECDSA certs.
func getMultiCert() string {
	return multiCertificateFile
}

// returns the names of pre-generated key and certificate files.
func getCertAndKey() (string, string) {
	return rsaPrivateKeyFile, certificateFile
}

// returns the names of pre-generated, encrypted private key and
// corresponding certificate file
func getCertAndEncryptedKey() (string, string) {
	return rsaEncryptedPrivateKeyFile, certificateOfEncryptedKeyFile
}

// If the cert files and directory are provided but are invalid, an error is
// returned.
func TestConfigServerTLSFailsIfUnableToLoadCerts(t *testing.T) {
	key, cert := getCertAndKey()
	ca := getMultiCert()

	tempFile, err := os.CreateTemp("", "cert-test")
	if err != nil {
		t.Fatal("Unable to create temporary empty file")
	}
	defer func() { _ = os.RemoveAll(tempFile.Name()) }()
	_ = tempFile.Close()

	for _, badFile := range []string{"not-a-file", tempFile.Name()} {
		for i := range 3 {
			files := []string{cert, key, ca}
			files[i] = badFile

			result, err := Server(Options{
				CertFile:   files[0],
				KeyFile:    files[1],
				CAFile:     files[2],
				ClientAuth: tls.VerifyClientCertIfGiven,
			})
			if err == nil || result != nil {
				t.Fatal("Expected a non-real file to error and return a nil TLS config")
			}
		}
	}
}

// If server cert and key are provided and client auth and client CA are not
// set, a tls config with only the server certs will be returned.
func TestConfigServerTLSServerCertsOnly(t *testing.T) {
	key, cert := getCertAndKey()

	keypair, err := tls.LoadX509KeyPair(cert, key)
	if err != nil {
		t.Fatal("Unable to load the generated cert and key")
	}

	tlsConfig, err := Server(Options{
		CertFile: cert,
		KeyFile:  key,
	})
	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure server TLS", err)
	}

	if len(tlsConfig.Certificates) != 1 {
		t.Fatal("Unexpected server certificates")
	}
	if len(tlsConfig.Certificates[0].Certificate) != len(keypair.Certificate) {
		t.Fatal("Unexpected server certificates")
	}
	for i, crt := range tlsConfig.Certificates[0].Certificate {
		if !bytes.Equal(crt, keypair.Certificate[i]) {
			t.Fatal("Unexpected server certificates")
		}
	}

	if !reflect.DeepEqual(tlsConfig.CipherSuites, DefaultServerAcceptedCiphers) {
		t.Fatal("Unexpected server cipher suites")
	}
	if tlsConfig.MinVersion != tls.VersionTLS12 {
		t.Fatal("Unexpected server TLS version")
	}
}

// If client CA is provided, it will only be used if the client auth is >=
// VerifyClientCertIfGiven
func TestConfigServerTLSClientCANotSetIfClientAuthTooLow(t *testing.T) {
	key, cert := getCertAndKey()
	ca := getMultiCert()

	tlsConfig, err := Server(Options{
		CertFile:   cert,
		KeyFile:    key,
		ClientAuth: tls.RequestClientCert,
		CAFile:     ca,
	})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure server TLS", err)
	}

	if len(tlsConfig.Certificates) != 1 {
		t.Fatal("Unexpected server certificates")
	}
	if tlsConfig.ClientAuth != tls.RequestClientCert {
		t.Fatal("ClientAuth was not set to what was in the options")
	}
	if tlsConfig.ClientCAs != nil { //nolint:staticcheck // Ignore SA1019: tlsConfig.ClientCAs.Subjects has been deprecated since Go 1.18: if s was returned by SystemCertPool, Subjects will not include the system roots.
		t.Fatalf("Client CAs should never have been set")
	}
}

// If client CA is provided, it will only be used if the client auth is >=
// VerifyClientCertIfGiven
func TestConfigServerTLSClientCASet(t *testing.T) {
	key, cert := getCertAndKey()
	ca := getMultiCert()

	tlsConfig, err := Server(Options{
		CertFile:   cert,
		KeyFile:    key,
		ClientAuth: tls.VerifyClientCertIfGiven,
		CAFile:     ca,
	})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure server TLS", err)
	}

	if len(tlsConfig.Certificates) != 1 {
		t.Fatal("Unexpected server certificates")
	}
	if tlsConfig.ClientAuth != tls.VerifyClientCertIfGiven {
		t.Fatal("ClientAuth was not set to what was in the options")
	}
	basePool, err := x509.SystemCertPool()
	if err != nil {
		t.Fatal("Failed to get SystemCertPool", err)
	}
	// because we are not enabling `ExclusiveRootPools`, any root pool will also contain the system roots
	if tlsConfig.ClientCAs == nil || len(tlsConfig.ClientCAs.Subjects()) != len(basePool.Subjects())+2 { //nolint:staticcheck // Ignore SA1019: tlsConfig.ClientCAs.Subjects has been deprecated since Go 1.18: if s was returned by SystemCertPool, Subjects will not include the system roots.
		t.Fatalf("Client CAs were never set correctly")
	}
}

// Exclusive root pools determines whether the CA pool will be a union of the system
// certificate pool and custom certs, or an exclusive or of the custom certs and system pool
//
// NOTE: In reality this behavior depends on the platform trust store and would
// be best validated via integration tests. Here we inject a fake system pool so
// the unit test can deterministically verify the intended semantics.
func TestConfigServerExclusiveRootPools(t *testing.T) {
	key, cert := getCertAndKey()

	customRoot, err := newTestTrustRoot()
	if err != nil {
		t.Fatal("Unable to generate fake custom CA", err)
	}

	ca := filepath.Join(t.TempDir(), "custom-ca.pem")
	if err := os.WriteFile(ca, customRoot.RootPEM, 0o644); err != nil {
		t.Fatal("Unable to write custom CA file", err)
	}

	systemLeaf, err := systemRootTrustedX509()
	if err != nil {
		t.Fatal("Unable to load fake system certificate", err)
	}

	testCerts := []*x509.Certificate{customRoot.LeafCert, systemLeaf}

	// ExclusiveRootPools not set, so should be able to verify both system-signed certs
	// and custom CA-signed certs
	tlsConfig, err := Server(Options{
		CertFile:   cert,
		KeyFile:    key,
		ClientAuth: tls.VerifyClientCertIfGiven,
		CAFile:     ca,

		systemCertPool: fakeSystemCertPool(),
	})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure server TLS", err)
	}

	for i, crt := range testCerts {
		if _, err := crt.Verify(x509.VerifyOptions{Roots: tlsConfig.ClientCAs}); err != nil {
			t.Fatalf("Unable to verify certificate %d: %v", i, err)
		}
	}

	// ExclusiveRootPools set and custom CA provided, so system certs should not be verifiable
	// and custom CA-signed certs should be verifiable
	tlsConfig, err = Server(Options{
		CertFile:           cert,
		KeyFile:            key,
		ClientAuth:         tls.VerifyClientCertIfGiven,
		CAFile:             ca,
		ExclusiveRootPools: true,
		systemCertPool:     fakeSystemCertPool(),
	})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure server TLS", err)
	}

	for i, crt := range testCerts {
		_, err := crt.Verify(x509.VerifyOptions{Roots: tlsConfig.ClientCAs})
		switch {
		case i == 0 && err != nil:
			t.Fatal("Unable to verify custom certificate, even though the root pool should have only the custom CA", err)
		case i == 1 && err == nil:
			t.Fatal("Successfully verified system root-signed certificate though the root pool should have only the custom CA", err)
		}
	}

	// No CA file provided means the server does not configure ClientCAs.
	tlsConfig, err = Server(Options{
		CertFile: cert,
		KeyFile:  key,

		systemCertPool: fakeSystemCertPool(),
	})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure server TLS", err)
	}
	if tlsConfig.ClientCAs != nil {
		t.Fatal("Expected ClientCAs to be nil when no CA file is provided")
	}
}

// If we provide a modifier to the server's default TLS configuration generator, it
// should be applied accordingly
func TestConfigServerDefaultWithTLSMinimumModifier(t *testing.T) {
	tlsVersions := []uint16{
		tls.VersionTLS11,
		tls.VersionTLS12,
	}

	for _, tlsVersion := range tlsVersions {
		servDefault := ServerDefault(func(c *tls.Config) {
			c.MinVersion = tlsVersion
		})

		if servDefault.MinVersion != tlsVersion {
			t.Fatalf("Unexpected min TLS version for default server TLS config: %d", servDefault.MinVersion)
		}
	}
}

// If we provide a modifier to the client's default TLS configuration generator, it
// should be applied accordingly
func TestConfigClientDefaultWithTLSMinimumModifier(t *testing.T) {
	tlsVersions := []uint16{
		tls.VersionTLS11,
		tls.VersionTLS12,
	}

	for _, tlsVersion := range tlsVersions {
		clientDefault := ClientDefault(func(c *tls.Config) {
			c.MinVersion = tlsVersion
		})

		if clientDefault.MinVersion != tlsVersion {
			t.Fatalf("Unexpected min TLS version for default client TLS config: %d", clientDefault.MinVersion)
		}
	}
}

// If a valid minimum version is specified in the options, the server's
// minimum version should be set accordingly
func TestConfigServerTLSMinVersionIsSetBasedOnOptions(t *testing.T) {
	versions := []uint16{
		tls.VersionTLS12,
	}
	key, cert := getCertAndKey()

	for _, v := range versions {
		tlsConfig, err := Server(Options{
			MinVersion: v,
			CertFile:   cert,
			KeyFile:    key,
		})

		if err != nil || tlsConfig == nil {
			t.Fatal("Unable to configure server TLS", err)
		}

		if tlsConfig.MinVersion != v {
			t.Fatal("Unexpected minimum TLS version: ", tlsConfig.MinVersion)
		}
	}
}

// An error should be returned if the specified minimum version for the server
// is too low, i.e. less than VersionTLS10
func TestConfigServerTLSMinVersionNotSetIfMinVersionIsTooLow(t *testing.T) {
	key, cert := getCertAndKey()

	_, err := Server(Options{
		MinVersion: tls.VersionTLS10,
		CertFile:   cert,
		KeyFile:    key,
	})

	if err == nil {
		t.Fatal("Should have returned an error for minimum version below TLS10")
	}
}

// An error should be returned if an invalid minimum version for the server is
// in the options struct
func TestConfigServerTLSMinVersionNotSetIfMinVersionIsInvalid(t *testing.T) {
	key, cert := getCertAndKey()

	_, err := Server(Options{
		MinVersion: 1,
		CertFile:   cert,
		KeyFile:    key,
	})

	if err == nil {
		t.Fatal("Should have returned error on invalid minimum version option")
	}
}

// The root CA is never set if InsecureSkipBoolean is set to true, but the
// default client options are set
func TestConfigClientTLSNoVerify(t *testing.T) {
	ca := getMultiCert()

	tlsConfig, err := Client(Options{CAFile: ca, InsecureSkipVerify: true})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure client TLS", err)
	}

	if tlsConfig.RootCAs != nil { //nolint:staticcheck // Ignore SA1019: tlsConfig.RootCAs.Subjects has been deprecated since Go 1.18: if s was returned by SystemCertPool, Subjects will not include the system roots.
		t.Fatal("Should not have set Root CAs", err)
	}

	if !reflect.DeepEqual(tlsConfig.CipherSuites, defaultCipherSuites) {
		t.Fatal("Unexpected client cipher suites")
	}
	if tlsConfig.MinVersion != tls.VersionTLS12 {
		t.Fatal("Unexpected client TLS version")
	}

	if tlsConfig.Certificates != nil {
		t.Fatal("Somehow client certificates were set")
	}
}

// The root CA is never set if InsecureSkipBoolean is set to false and root CA
// is not provided.
func TestConfigClientTLSNoRoot(t *testing.T) {
	tlsConfig, err := Client(Options{})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure client TLS", err)
	}

	if tlsConfig.RootCAs != nil {
		t.Fatal("Should not have set Root CAs", err)
	}

	if !reflect.DeepEqual(tlsConfig.CipherSuites, defaultCipherSuites) {
		t.Fatal("Unexpected client cipher suites")
	}
	if tlsConfig.MinVersion != tls.VersionTLS12 {
		t.Fatal("Unexpected client TLS version")
	}

	if tlsConfig.Certificates != nil {
		t.Fatal("Somehow client certificates were set")
	}
}

// The RootCA is set if the file is provided and InsecureSkipVerify is false
func TestConfigClientTLSRootCAFileWithOneCert(t *testing.T) {
	ca := getMultiCert()

	tlsConfig, err := Client(Options{CAFile: ca})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure client TLS", err)
	}
	basePool, err := x509.SystemCertPool()
	if err != nil {
		t.Fatal("Failed to get SystemCertPool", err)
	}
	// because we are not enabling `ExclusiveRootPools`, any root pool will also contain the system roots
	if tlsConfig.RootCAs == nil || len(tlsConfig.RootCAs.Subjects()) != len(basePool.Subjects())+2 { //nolint:staticcheck // Ignore SA1019: tlsConfig.ClientCAs.Subjects has been deprecated since Go 1.18: if s was returned by SystemCertPool, Subjects will not include the system roots.
		t.Fatal("Root CAs not set properly", err)
	}
	if tlsConfig.Certificates != nil {
		t.Fatal("Somehow client certificates were set")
	}
}

// An error is returned if a root CA is provided but the file doesn't exist.
func TestConfigClientTLSNonexistentRootCAFile(t *testing.T) {
	tlsConfig, err := Client(Options{CAFile: "nonexistent"})

	if err == nil || tlsConfig != nil {
		t.Fatal("Should not have been able to configure client TLS", err)
	}
}

// An error is returned if either the client cert or the key are provided
// but invalid or blank.
func TestConfigClientTLSClientCertOrKeyInvalid(t *testing.T) {
	key, cert := getCertAndKey()

	tempFile, err := os.CreateTemp("", "cert-test")
	if err != nil {
		t.Fatal("Unable to create temporary empty file")
	}
	defer func() { _ = os.Remove(tempFile.Name()) }()
	_ = tempFile.Close()

	for i := range 2 {
		for _, invalid := range []string{"not-a-file", "", tempFile.Name()} {
			files := []string{cert, key}
			files[i] = invalid

			tlsConfig, err := Client(Options{CertFile: files[0], KeyFile: files[1]})
			if err == nil || tlsConfig != nil {
				t.Fatal("Should not have been able to configure client TLS", err)
			}
		}
	}
}

// The certificate is set if the client cert and client key are provided and
// valid.
func TestConfigClientTLSValidClientCertAndKey(t *testing.T) {
	key, cert := getCertAndKey()

	keypair, err := tls.LoadX509KeyPair(cert, key)
	if err != nil {
		t.Fatal("Unable to load the generated cert and key")
	}

	tlsConfig, err := Client(Options{CertFile: cert, KeyFile: key})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure client TLS", err)
	}

	if len(tlsConfig.Certificates) != 1 {
		t.Fatal("Unexpected client certificates")
	}
	if len(tlsConfig.Certificates[0].Certificate) != len(keypair.Certificate) {
		t.Fatal("Unexpected client certificates")
	}
	for i, crt := range tlsConfig.Certificates[0].Certificate {
		if !bytes.Equal(crt, keypair.Certificate[i]) {
			t.Fatal("Unexpected client certificates")
		}
	}

	if tlsConfig.RootCAs != nil {
		t.Fatal("Root CAs should not have been set", err)
	}
}

func TestConfigClientTLSEncryptedKey(t *testing.T) {
	key, cert := getCertAndEncryptedKey()

	tlsConfig, err := Client(Options{
		CertFile: cert,
		KeyFile:  key,
	})
	if !errors.Is(err, errEncryptedKeyDeprecated) {
		t.Errorf("Expected %v but got %v", errEncryptedKeyDeprecated, err)
	}
	if tlsConfig != nil {
		t.Errorf("Expected nil but got %v", tlsConfig)
	}
}

// Exclusive root pools determines whether the CA pool will be a union of the system
// certificate pool and custom certs, or an exclusive or of the custom certs and system pool
//
// NOTE: In reality this behavior depends on the platform trust store and would
// be best validated via integration tests. Here we inject a fake system pool so
// the unit test can deterministically verify the intended semantics.
func TestConfigClientExclusiveRootPools(t *testing.T) {
	key, cert := getCertAndKey()

	customRoot, err := newTestTrustRoot()
	if err != nil {
		t.Fatal("Unable to generate fake custom CA", err)
	}

	ca := filepath.Join(t.TempDir(), "custom-ca.pem")
	if err := os.WriteFile(ca, customRoot.RootPEM, 0o644); err != nil {
		t.Fatal("Unable to write custom CA file", err)
	}

	systemLeaf, err := systemRootTrustedX509()
	if err != nil {
		t.Fatal("Unable to load fake system certificate", err)
	}

	testCerts := []*x509.Certificate{customRoot.LeafCert, systemLeaf}

	// ExclusiveRootPools not set, so should be able to verify both system-signed certs
	// and custom CA-signed certs
	tlsConfig, err := Client(Options{
		CAFile:         ca,
		systemCertPool: fakeSystemCertPool(),
	})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure client TLS", err)
	}

	for i, crt := range testCerts {
		if _, err := crt.Verify(x509.VerifyOptions{Roots: tlsConfig.RootCAs}); err != nil {
			t.Fatalf("Unable to verify certificate %d: %v", i, err)
		}
	}

	// ExclusiveRootPools set and custom CA provided, so system certs should not be verifiable
	// and custom CA-signed certs should be verifiable
	tlsConfig, err = Client(Options{
		CAFile:             ca,
		ExclusiveRootPools: true,
		systemCertPool:     fakeSystemCertPool(),
	})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure client TLS", err)
	}

	for i, crt := range testCerts {
		_, err := crt.Verify(x509.VerifyOptions{Roots: tlsConfig.RootCAs})
		switch {
		case i == 0 && err != nil:
			t.Fatal("Unable to verify custom certificate, even though the root pool should have only the custom CA", err)
		case i == 1 && err == nil:
			t.Fatal("Successfully verified system root-signed certificate though the root pool should have only the custom CA", err)
		}
	}

	// No CA file provided means the client leaves RootCAs unset.
	tlsConfig, err = Client(Options{
		CertFile:       cert,
		KeyFile:        key,
		systemCertPool: fakeSystemCertPool(),
	})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure client TLS", err)
	}
	if tlsConfig.RootCAs != nil {
		t.Fatal("Expected RootCAs to be nil when no CA file is provided")
	}
}

// If a valid MinVersion is specified in the options, the client's
// minimum version should be set accordingly
func TestConfigClientTLSMinVersionIsSetBasedOnOptions(t *testing.T) {
	key, cert := getCertAndKey()

	tlsConfig, err := Client(Options{
		MinVersion: tls.VersionTLS12,
		CertFile:   cert,
		KeyFile:    key,
	})

	if err != nil || tlsConfig == nil {
		t.Fatal("Unable to configure client TLS", err)
	}

	if tlsConfig.MinVersion != tls.VersionTLS12 {
		t.Fatal("Unexpected minimum TLS version: ", tlsConfig.MinVersion)
	}
}

// An error should be returned if the specified minimum version for the client
// is too low, i.e. less than VersionTLS12
func TestConfigClientTLSMinVersionNotSetIfMinVersionIsTooLow(t *testing.T) {
	key, cert := getCertAndKey()

	_, err := Client(Options{
		MinVersion: tls.VersionTLS11,
		CertFile:   cert,
		KeyFile:    key,
	})

	if err == nil {
		t.Fatal("Should have returned an error for minimum version below TLS12")
	}
}

// An error should be returned if an invalid minimum version for the client is
// in the options struct
func TestConfigClientTLSMinVersionNotSetIfMinVersionIsInvalid(t *testing.T) {
	key, cert := getCertAndKey()

	_, err := Client(Options{
		MinVersion: 1,
		CertFile:   cert,
		KeyFile:    key,
	})

	if err == nil {
		t.Fatal("Should have returned error on invalid minimum version option")
	}
}
