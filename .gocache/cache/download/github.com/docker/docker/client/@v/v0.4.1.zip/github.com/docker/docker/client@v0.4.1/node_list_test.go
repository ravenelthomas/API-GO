package client

import (
	"fmt"
	"net/http"
	"testing"

	cerrdefs "github.com/containerd/errdefs"
	"github.com/moby/moby/api/types/swarm"
	"gotest.tools/v3/assert"
	is "gotest.tools/v3/assert/cmp"
)

func TestNodeListError(t *testing.T) {
	client, err := New(WithMockClient(errorMock(http.StatusInternalServerError, "Server error")))
	assert.NilError(t, err)

	_, err = client.NodeList(t.Context(), NodeListOptions{})
	assert.Check(t, is.ErrorType(err, cerrdefs.IsInternal))
}

func TestNodeList(t *testing.T) {
	const expectedURL = "/nodes"

	listCases := []struct {
		options             NodeListOptions
		expectedQueryParams map[string]string
	}{
		{
			options: NodeListOptions{},
			expectedQueryParams: map[string]string{
				"filters": "",
			},
		},
		{
			options: NodeListOptions{
				Filters: make(Filters).
					Add("label", "label1", "label2"),
			},
			expectedQueryParams: map[string]string{
				"filters": `{"label":{"label1":true,"label2":true}}`,
			},
		},
	}
	for _, listCase := range listCases {
		client, err := New(WithMockClient(func(req *http.Request) (*http.Response, error) {
			if err := assertRequest(req, http.MethodGet, expectedURL); err != nil {
				return nil, err
			}
			query := req.URL.Query()
			for key, expected := range listCase.expectedQueryParams {
				actual := query.Get(key)
				if actual != expected {
					return nil, fmt.Errorf("%s not set in URL query properly. Expected '%s', got %s", key, expected, actual)
				}
			}
			return mockJSONResponse(http.StatusOK, nil, []swarm.Node{
				{ID: "node_id1"},
				{ID: "node_id2"},
			})(req)
		}))
		assert.NilError(t, err)

		result, err := client.NodeList(t.Context(), listCase.options)
		assert.NilError(t, err)
		assert.Check(t, is.Len(result.Items, 2))
	}
}
