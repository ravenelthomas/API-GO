module github.com/moby/moby/api

go 1.24

require (
	github.com/docker/go-units v0.5.0
	github.com/moby/docker-image-spec v1.3.1
	github.com/opencontainers/go-digest v1.0.0
	github.com/opencontainers/image-spec v1.1.1
	gotest.tools/v3 v3.5.2
	pgregory.net/rapid v1.2.0
)

require github.com/google/go-cmp v0.7.0 // indirect
